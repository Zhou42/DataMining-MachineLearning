Greetings!

MNIST helper is a set of python functions which comes handy while builing classifiers
using the famous MNIST Digits dataset.

The functions included are for tasks like

1. Width normalization
2. Elastic deformation
3. Cropping 
4. Prepare a normalized (divided by 255) image vector

Detailed documentation is added to the code, and some of the functions which I have added had been taken
from the Internet

Requirements

1. Opencv-2.x python
2. numpy
3. scipy

As this is my very first github upload, there will be room for plenty of improvements. 
Please feel free to contact me @ vinayak.vvs@gmail.com

Vinayak Sasidharan V S
01/01/2015
